import { useMemo } from "react";
import { useAppContext } from "../context/AppContext";

/**
 * useThemeTokens
 *
 * Custom hook that derives ready-to-use style objects from the
 * config theme tokens. Components call this to get inline styles
 * or class helpers — they never hardcode color/spacing values.
 *
 * This is NOT just a useContext wrapper: it processes tokens into
 * computed style objects and utility helpers.
 */
export function useThemeTokens() {
  const { theme, config } = useAppContext();
  const spacing = config.spacing;
  const fonts = config.fonts;

  // Memoized derived style helpers
  const styles = useMemo(
    () => ({
      // Card surface
      card: {
        background: theme.cardBg,
        border: `1px solid ${theme.border}`,
        borderRadius: "16px",
      },
      // Primary button
      btnPrimary: {
        background: theme.accent,
        color: "#fff",
        border: "none",
        borderRadius: "12px",
        padding: `${spacing.sm} ${spacing.lg}`,
        fontFamily: fonts.body,
        fontWeight: 700,
        cursor: "pointer",
      },
      // Ghost button
      btnGhost: {
        background: "transparent",
        color: theme.textPrimary,
        border: `1px solid ${theme.border}`,
        borderRadius: "12px",
        padding: `${spacing.sm} ${spacing.lg}`,
        fontFamily: fonts.body,
        fontWeight: 600,
        cursor: "pointer",
      },
      // Section heading
      heading: {
        fontFamily: fonts.display,
        color: theme.textPrimary,
      },
      // Muted text
      muted: {
        color: theme.textSecondary,
        fontFamily: fonts.body,
      },
      // Input field
      input: {
        background: theme.cardBg,
        color: theme.textPrimary,
        border: `1px solid ${theme.border}`,
        borderRadius: "10px",
        padding: `${spacing.sm} ${spacing.md}`,
        fontFamily: fonts.body,
        fontSize: "0.95rem",
        width: "100%",
        outline: "none",
      },
      // Accent badge / pill
      badge: {
        background: theme.accentSoft,
        color: theme.accent,
        borderRadius: "20px",
        padding: `3px ${spacing.sm}`,
        fontSize: "0.75rem",
        fontWeight: 700,
        fontFamily: fonts.body,
      },
      // Page wrapper
      page: {
        background: theme.bgSecondary,
        minHeight: "100vh",
        paddingTop: "68px",
      },
    }),
    [theme, spacing, fonts]
  );

  // Spacing shorthand helper: s("md") → "1rem"
  const s = (key) => spacing[key] ?? key;

  // Color shorthand helper: c("accent") → "#e8610a"
  const c = (key) => theme[key] ?? key;

  return { styles, s, c, theme, spacing, fonts };
}